# Overview

This directory contains a skeletal Angular application for the leave managment system.

# Pre-requisites
  * see https://angular.io/guide/quickstart
  * node -v
  * npm -v
  * ng -v

# running locally

  * `ng serve --open`  