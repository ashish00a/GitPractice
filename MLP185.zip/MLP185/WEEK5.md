# Week #5: Course Materials
    * Junit
    * JMockit

The objective of week #5 is to complete the Cli implementation for all the functionalities. 
Primary objective is to complete the junit and jmockit testing
A secondary objective is to get the jenkins incorporated into the development life cycle. This means adding unit tests for  the required coverage.

# Week #5

    * Sprint goals
       * Trello Project Board Task: Jenkins integration
     
# Reading material

## Must-Read

## Nice-To-Read

## Go-Deep

  
