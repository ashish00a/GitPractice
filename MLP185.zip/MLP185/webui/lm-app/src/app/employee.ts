export class Employee {
    empId: number;
    name: String;
    email: String;
    phoneNumber: number;
    mgrId: number;
    constructor(id: number) {
      this.empId = id;
    }
}
