# database

This directory will contain the DDLs and DMLs to setup the databases for your project. We will have
one development environment, and a couple of test environments and a production environment. 

