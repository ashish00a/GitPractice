This folder contains the integration tests for the 
leavemanager rest service. We will be writing these
tests using the RestAssured framework.
